public class AleatorioHijo {
    public static void main(String[] args) {
        int numAl = (int)(Math.random()*10);
        System.out.print(numAl);
    }
}
